/**
 * @author https://vue-admin-beautiful.com （不想保留author可删除）
 * @description babel.config
 */
module.exports = {
  presets: ['@vue/cli-plugin-babel/preset'],
}
