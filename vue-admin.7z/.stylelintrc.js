/**
 * @author https://vue-admin-beautiful.com （不想保留author可删除）
 * @description stylelint
 */
module.exports = {
  extends: ['stylelint-config-recess-order', 'stylelint-config-prettier'],
}
